<?php
	
		$dbaccess = array(	'host' => "localhost",
                    'user' => "USER",
                    'password' => "PWD",
                    'database' => "DB_NAME"
                  );

?>