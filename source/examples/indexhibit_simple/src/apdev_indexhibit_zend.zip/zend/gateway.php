<?php
  error_reporting(E_ALL);
  ini_set("display_errors", "on");
  require_once "Zend/Amf/Server.php";
  require_once "com/apdevblog/examples/indexhibit/Indexhibit.php";
  $server = new Zend_Amf_Server();
  $server->setClass('Indexhibit');
  $server->setClassMap('com.apdevblog.examples.indexhibit.model.vo.ExhibitVo', 'ExhibitVo');
  $server->setClassMap('com.apdevblog.examples.indexhibit.model.vo.ImageVo', 'ImageVo');
  echo $server->handle();
?>