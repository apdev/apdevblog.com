<?php
	
		$dbaccess = array(	'host' => "HOST_URL",
                    'user' => "USERNAME",
                    'password' => "PASSWORD",
                    'database' => "DATABASE_NAME"
                  );

?>